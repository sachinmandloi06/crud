import React from 'react'

const Navbar = () => {
  return (
    <nav className="navbar bg-body-tertiary shadow">
  <div className="container-fluid">
    <a className="navbar-brand" href="#">Todo</a>
  </div>
</nav>
  )
}

export default Navbar
